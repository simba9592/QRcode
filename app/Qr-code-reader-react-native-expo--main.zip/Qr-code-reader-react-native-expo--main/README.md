# Qr-code-reader-react-native-expo-

[Tutorial is here](https://youtu.be/nRyDPNisjD8)

[Video Tutorial](https://www.youtube.com/watch?v=3mMyd3r2LRc&list=PLO3Dk6jx9EITZ1EMC3eUYDEx9w13dNm-X&index=17)
